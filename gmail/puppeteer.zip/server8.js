const admin = require('./database')

const SIZE = '8'


const GmailClient = require('./gmail-api')
const ID = require('./ID')
  
const database = new admin()

database.connect((error) => {
    if(!error) {
        new GmailClient(database, new ID().getServer(), new ID().getSirial(), SIZE).start()
    }
})